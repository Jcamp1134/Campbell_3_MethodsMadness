package slickexample;


class Blocked {

	public static boolean[][] Blocked;

	public static boolean[][] getblocked() {

		return Blocked;

	}

};
